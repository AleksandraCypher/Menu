﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp1.Kontroler;
using WpfApp1.Modeli;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int Number;
        

        Меню Мое_Меню;
        Оформление оформление;
        int Itog;


        public MainWindow()
        {
            InitializeComponent();
            Мое_Меню = new Меню();
            оформление = new Оформление();
            this.DataContext = Мое_Меню;
            Julia.ItemsSource = Мое_Меню.menu;
            Bulkfrog.ItemsSource = оформление.Lipton;
            Oksana.Text = Convert.ToString(1);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (0 < Convert.ToInt32(Oksana.Text))
                {
                    Number = Convert.ToInt32(Oksana.Text);
                    Politkovskaya.ItemsSource = оформление.Islam;
                    оформление.Vybrat(Мое_Меню.menu [Julia.SelectedIndex], Number);
                    
                    foreach (Заказ zakaz in оформление.Islam)
                    {
                        Itog = zakaz.eda.price * zakaz.Количество + Itog;
                    }
                    FinalpriceNavalny.Content = Itog.ToString();
                }
                else MessageBox.Show("Совы не то, чем кажутся");
            }
            catch (Exception)
            {
                MessageBox.Show("Печеньки не то, чем кажутся");
            }

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            оформление.clean_off();
            Politkovskaya.ItemsSource = оформление.Islam;
            Itog = 0;
            FinalpriceNavalny.Content = Itog.ToString();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            оформление.Ovormit();
            Politkovskaya.ItemsSource = оформление.Islam;
            Itog = 0;
            FinalpriceNavalny.Content = Itog.ToString();
        }

        private void Bulkfrog_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Politkovskaya.ItemsSource = оформление.Lipton[Bulkfrog.SelectedIndex].SpisokBlud;
        }
    }
}
