﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp1.Modeli;

namespace WpfApp1.Kontroler
{
    struct Заказ
    {
        public Bludo eda { get; set; }
        public int Количество { get; set; }
        public int time { get; set; }
    }
}
